package comp254.lab2.ex1;

public class Main {
}
